#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QSplitter>
#include <QLabel>
#include <QTextEdit>

class MainWindow : public QMainWindow {
    Q_OBJECT

enum class ChordDisplayMode {
    CIL, // Chord-In-Line (Standard ChordPro)
    CAL  // Chord-Above-Lyrics (Traditional Lead Sheet)
};

public:
    enum AppState { Idle, OpenEdit, PlayAlong };

    MainWindow(QWidget *parent = nullptr);
    void setAppState(AppState state);

private slots:
    void handleFileOpen();
    void handleFileSave();

private:
    void setupMenus();
    void setupLayout();
    void setupToolBar();
    void toggleDisplayMode();
    QString runInitialParse(const QString &rawInput);

    ChordDisplayMode m_currentMode = ChordDisplayMode::CIL;

    // UI Elements
    QSplitter *mainSplitter;
    QPlainTextEdit *originalEditor;
    QTextEdit *parsedEditor;
    QLabel *statusLabel;

    AppState currentState;
};

#endif