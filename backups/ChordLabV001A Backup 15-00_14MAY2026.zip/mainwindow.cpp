#include "MainWindow.h"
#include <QMenuBar>
#include <QToolBar>
#include <QHBoxLayout>
#include <QPushButton>
#include <QStatusBar>
#include <QGuiApplication>
#include <QScreen>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QTextCharFormat>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    // 1. Scale to 60% of available screen
    QScreen *screen = QGuiApplication::primaryScreen();
    QSize size = screen->availableGeometry().size();
    resize(size.width() * 0.75, size.height() * 0.6);

    setupMenus();
    setupToolBar();
    setupLayout();
    setAppState(Idle); // Start in "Neutral" mode

    // Reserved Toolbar Space
    //    addToolBar("Transport & Controls");
    // --> btn->setIcon(QIcon(":/icons/gig-list.png"));
}

void MainWindow::setupMenus() {
    QMenu *fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction("&Open...", this, &MainWindow::handleFileOpen, QKeySequence::Open);
    fileMenu->addAction("&Save Standardized", this, &MainWindow::handleFileSave, QKeySequence::Save);
    fileMenu->addSeparator();
    fileMenu->addAction("E&xit", this, &QWidget::close);
}

void MainWindow::setupToolBar() {
    QToolBar *settingsToolBar = addToolBar("Critical Settings");

    // Create a container for our buttons
    QWidget *container = new QWidget();
    QHBoxLayout *layout = new QHBoxLayout(container);
    layout->setContentsMargins(5, 2, 5, 2);
    layout->setSpacing(10);

    // Add "Placeholder" Blue Buttons
    QString buttonStyle = "QPushButton { background-color: #0047AB; color: white; border-radius: 4px; padding: 5px; min-width: 60px; }";

    for(int i = 0; i < 4; ++i) {
        QPushButton *btn = new QPushButton(QString("Opt %1").arg(i + 1));
        btn->setStyleSheet(buttonStyle);
        layout->addWidget(btn);
    }

    settingsToolBar->addWidget(container);
    // Inside setupToolBar()
    QPushButton *viewToggleBtn = new QPushButton("View: CIL/CAL");
    viewToggleBtn->setStyleSheet("QPushButton { background-color: #0047AB; color: white; font-weight: bold; padding: 5px; }");

    // Connect the button to the logic
    connect(viewToggleBtn, &QPushButton::clicked, this, &MainWindow::toggleDisplayMode);

    layout->addWidget(viewToggleBtn);
}

void MainWindow::setupLayout() {
    mainSplitter = new QSplitter(Qt::Horizontal, this);

    // Left Side: Original/Raw ChoPro
    originalEditor = new QPlainTextEdit(this);
    originalEditor->setPlaceholderText("Original File Content...");
    // Use Monospaced font for alignment of [|] [/] [.]
    QFont monoFont("Consolas", 10);
    originalEditor->setFont(monoFont);

    // Right Side: Expert/Parsed Content
    parsedEditor = new QTextEdit(this);
    parsedEditor->setPlaceholderText("Parsed & Standardized Output...");
    parsedEditor->setFont(monoFont);
    parsedEditor->setReadOnly(true); // Expert view starts as read-only

    mainSplitter->addWidget(originalEditor);
    mainSplitter->addWidget(parsedEditor);

    setCentralWidget(mainSplitter);
}

void MainWindow::setAppState(AppState state) {
    currentState = state;
    switch(state) {
    case Idle:
        statusBar()->showMessage("Ready. Open a ChordPro file to begin.");
        mainSplitter->hide();
        break;
    case OpenEdit:
        statusBar()->showMessage("Editing Mode: Analyzing ChordPro syntax...");
        mainSplitter->show();
        break;
    case PlayAlong:
        statusBar()->showMessage("Play-along Mode Active.");
        // Future: Hide originalEditor, maximize parsed view or renderer
        break;
    }
}

// This is the implementation for the Save action
void MainWindow::handleFileSave() {
    statusBar()->showMessage("Save triggered - awaiting logic.");
}

void MainWindow::handleFileOpen() {
    // 1. Get the file path from the user
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("Open ChordPro File"), "", tr("ChordPro Files (*.chopro *.pro *.txt *.crd)"));

    if (fileName.isEmpty()) {
        return;
    }

    // 2. Attempt to open and read the file
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Error"), tr("Could not open file: ") + file.errorString());
        return;
    }

    QTextStream in(&file);
    QString content = in.readAll();
    file.close();

    // 3. Populate the 'Original' editor and update State
    originalEditor->setPlainText(content);
    setAppState(OpenEdit);

    // 4. Run the initial 'Expert' Parser (The Meta-data Pass)
    // For now, we'll call a helper function to populate the right-hand side
//    QString testHtml = "<html><body><b style='color:red;'>If this is red and bold, HTML is working!</b></body></html>";
//    parsedEditor->setHtml(testHtml);

    QString expertVersion = runInitialParse(content);
    parsedEditor->setHtml(expertVersion);
    statusBar()->showMessage(tr("Loaded: ") + fileName);
}

QString MainWindow::runInitialParse(const QString &rawInput) {

    // 1. Define theme variables
    QString colorChord = "darkblue";
    QString colorLyrics = "#1A1A1A";

    // 2. Start with a proper HTML header and CSS
    // white-space: pre is vital for guitar alignment
    QString result = "<html><head><style>"
                     "body { font-family: 'Consolas', monospace; white-space: pre; background-color: white; color: " + colorLyrics + "; }"
                                     ".chord { color: " + colorChord + "; font-weight: bold; }"
                                    "</style></head><body>";

    // 3. Process the lines
    QStringList lines = rawInput.split('\n');

    // 1. Metadata Pre-Pass
    QRegularExpression titleRegex("\\{(?:title|t):\\s*(.*)\\}", QRegularExpression::CaseInsensitiveOption);
    QRegularExpression keyRegex("\\{(?:key|k):\\s*(.*)\\}", QRegularExpression::CaseInsensitiveOption);

    auto titleMatch = titleRegex.match(rawInput);
    auto keyMatch = keyRegex.match(rawInput);

    QString songTitle = titleMatch.hasMatch() ? titleMatch.captured(1).trimmed() : "Untitled Song";
    QString songKey = keyMatch.hasMatch() ? keyMatch.captured(1).trimmed() : "Not Set";

    // 2. Build the Visual Header
    result += "<div style='background-color: #f8f9fa; padding: 15px; border-bottom: 2px solid " + colorLyrics + "; margin-bottom: 15px;'>";
    result += "<span style='font-size: 1.4em; font-weight: bold; color: " + colorLyrics + ";'>" + songTitle + "</span><br>";
    result += "<span style='color: #666;'>Key: <b>" + songKey + "</b></span>";
    result += "</div>";

    for (QString line : lines) {
        line.remove('\r');
        if (line.isEmpty()) { result += "<br>"; continue; }

        // Skip Metadata tags handled by the header
        if (line.contains("{title:", Qt::CaseInsensitive) || line.contains("{t:", Qt::CaseInsensitive) ||
            line.contains("{key:", Qt::CaseInsensitive) || line.contains("{k:", Qt::CaseInsensitive)) {
            continue;
        }

        // Handle Standard Directives
        if (line.startsWith("{")) {
            // Chorus Start: Indent and add the blue bar
            if (line.contains("start_of_chorus", Qt::CaseInsensitive) || line.contains("{soc", Qt::CaseInsensitive)) {
                result += "<div style='border-left: 5px solid #0047AB; padding-left: 15px; margin: 10px 0; background-color: #f0f7ff;'>";
                // We don't want to print the {soc} tag itself anymore
                continue;
            }

            // Chorus End: Close the container
            if (line.contains("end_of_chorus", Qt::CaseInsensitive) || line.contains("{eoc", Qt::CaseInsensitive)) {
                result += "</div>";
                continue;
            }

            // Annotations: {comment: Chorus}
            if (line.contains("{c:", Qt::CaseInsensitive) || line.contains("{comment:", Qt::CaseInsensitive)) {
                QString commentText = line.section(':', 1).chopped(1).trimmed();
                result += "<div style='color: #444; background: #eee; padding: 2px 8px; border-radius: 4px; font-weight: bold; margin: 5px 0; display: inline-block;'>"
                          + commentText + "</div><br>";
                continue;
            }
        }

        // Process Chords (CIL Mode)
        if (m_currentMode == ChordDisplayMode::CIL) {
            line.replace(QRegularExpression("\\[(.*?)\\]"), "<span class='chord'>[\\1]</span>");
            result += line + "<br>";
        }
        else {
            // --- CAL MODE LOGIC ---
            QString chordLine = "";
            QString lyricLine = "";
            int currentPos = 0;

            // Find all [Chords]
            QRegularExpression chordRegex("\\[(.*?)\\]");
            auto i = chordRegex.globalMatch(line);

            while (i.hasNext()) {
                auto match = i.next();

                // 1. Fill the 'gap' in both lines up to the chord's position
                int leadingLength = match.capturedStart() - currentPos;
                QString gap = line.mid(currentPos, leadingLength);

                lyricLine += gap;
                chordLine += QString(gap.length(), ' '); // Match spaces exactly

                // 2. Add the Chord to the top line (no brackets)
                QString chordName = match.captured(1);
                chordLine += "<span class='chord'>" + chordName + "</span>";

                // 3. Update position (skip the [chord] block in the original)
                currentPos = match.capturedEnd();
            }

            // 4. Add the remaining lyrics after the last chord
            lyricLine += line.mid(currentPos);

            // 5. Stack them with a single break in between
            result += chordLine + "<br>" + lyricLine + "<br>";
        }
    }
    result += "</body></html>";
    return result;
}

void MainWindow::toggleDisplayMode() {
    // 1. Toggle the mode
    m_currentMode = (m_currentMode == ChordDisplayMode::CIL) ?
                        ChordDisplayMode::CAL : ChordDisplayMode::CIL;

    // 2. Update the status bar so the user knows what happened
    QString modeName = (m_currentMode == ChordDisplayMode::CIL) ? "ChordPro (CIL)" : "LeadSheet (CAL)";
    statusBar()->showMessage("Display Mode Switched to: " + modeName);

    // 3. Refresh the "Expert" view immediately
    QString currentContent = originalEditor->toPlainText();
    parsedEditor->setHtml(runInitialParse(currentContent));
}