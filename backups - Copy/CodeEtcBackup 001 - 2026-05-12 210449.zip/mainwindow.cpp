#include "MainWindow.h"
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QGuiApplication>
#include <QScreen>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QTextCharFormat>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    // 1. Scale to 60% of available screen
    QScreen *screen = QGuiApplication::primaryScreen();
    QSize size = screen->availableGeometry().size();
    resize(size.width() * 0.6, size.height() * 0.6);

    setupMenus();
    setupLayout();
    setAppState(Idle); // Start in "Neutral" mode
}

void MainWindow::setupLayout() {
    mainSplitter = new QSplitter(Qt::Horizontal, this);

    // Left Side: Original/Raw ChoPro
    originalEditor = new QPlainTextEdit(this);
    originalEditor->setPlaceholderText("Original File Content...");
    // Use Monospaced font for alignment of [|] [/] [.]
    QFont monoFont("Consolas", 10);
    originalEditor->setFont(monoFont);

    // Right Side: Expert/Parsed Content
    parsedEditor = new QTextEdit(this);
    parsedEditor->setPlaceholderText("Parsed & Standardized Output...");
    parsedEditor->setFont(monoFont);
    parsedEditor->setReadOnly(true); // Expert view starts as read-only

    mainSplitter->addWidget(originalEditor);
    mainSplitter->addWidget(parsedEditor);

    setCentralWidget(mainSplitter);
}

void MainWindow::setupMenus() {
    QMenu *fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction("&Open...", this, &MainWindow::handleFileOpen, QKeySequence::Open);
    fileMenu->addAction("&Save Standardized", this, &MainWindow::handleFileSave, QKeySequence::Save);
    fileMenu->addSeparator();
    fileMenu->addAction("E&xit", this, &QWidget::close);

    // Reserved Toolbar Space
    addToolBar("Transport & Controls");
}

void MainWindow::setAppState(AppState state) {
    currentState = state;
    switch(state) {
    case Idle:
        statusBar()->showMessage("Ready. Open a ChordPro file to begin.");
        mainSplitter->hide();
        break;
    case OpenEdit:
        statusBar()->showMessage("Editing Mode: Analyzing ChordPro syntax...");
        mainSplitter->show();
        break;
    case PlayAlong:
        statusBar()->showMessage("Play-along Mode Active.");
        // Future: Hide originalEditor, maximize parsed view or renderer
        break;
    }
}

// This is the implementation for the Open action
//void MainWindow::handleFileOpen() {
    // For now, we just change the state to see if it works
//    setAppState(OpenEdit);
//    statusBar()->showMessage("Open triggered - awaiting logic.");
//}

// This is the implementation for the Save action
void MainWindow::handleFileSave() {
    statusBar()->showMessage("Save triggered - awaiting logic.");
}

void MainWindow::handleFileOpen() {
    // 1. Get the file path from the user
    QString fileName = QFileDialog::getOpenFileName(this,
                                                    tr("Open ChordPro File"), "", tr("ChordPro Files (*.chopro *.pro *.txt *.crd)"));

    if (fileName.isEmpty()) {
        return;
    }

    // 2. Attempt to open and read the file
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("Error"), tr("Could not open file: ") + file.errorString());
        return;
    }

    QTextStream in(&file);
    QString content = in.readAll();
    file.close();

    // 3. Populate the 'Original' editor and update State
    originalEditor->setPlainText(content);
    setAppState(OpenEdit);

    // 4. Run the initial 'Expert' Parser (The Meta-data Pass)
    // For now, we'll call a helper function to populate the right-hand side
//    QString testHtml = "<html><body><b style='color:red;'>If this is red and bold, HTML is working!</b></body></html>";
//    parsedEditor->setHtml(testHtml);

    QString expertVersion = runInitialParse(content);
    parsedEditor->setHtml(expertVersion);
    statusBar()->showMessage(tr("Loaded: ") + fileName);
}

QString MainWindow::runInitialParse(const QString &rawInput) {
    // 1. Define theme variables
    QString colorChord = "darkblue";
    QString colorLyrics = "#1A1A1A";

    // 2. Start with a proper HTML header and CSS
    // white-space: pre is vital for guitar alignment
    QString result = "<html><head><style>"
                     "body { font-family: 'Consolas', monospace; white-space: pre; background-color: white; color: " + colorLyrics + "; }"
                                     ".chord { color: " + colorChord + "; font-weight: bold; }"
                                    "</style></head><body>";

    // 3. Process the lines
    QStringList lines = rawInput.split('\n');

    for (QString line : lines) {
        line.remove('\r');
        if (line.isEmpty()) { result += "<br>"; continue; }

        // Directives (Tags) stay the same in both modes
        if (line.startsWith("{")) {
            // ... (Keep your existing {c:}, {sog} logic here) ...
            result += line + "<br>";
            continue;
        }

        if (m_currentMode == ChordDisplayMode::CIL) {
            // ... (Keep your existing replacement logic here) ...
            result += line + "<br>";
        }
        else {
            // --- CAL MODE LOGIC ---
            QString chordLine = "";
            QString lyricLine = "";
            int currentPos = 0;

            // Find all [Chords]
            QRegularExpression chordRegex("\\[(.*?)\\]");
            auto i = chordRegex.globalMatch(line);

            while (i.hasNext()) {
                auto match = i.next();

                // 1. Fill the 'gap' in both lines up to the chord's position
                int leadingLength = match.capturedStart() - currentPos;
                QString gap = line.mid(currentPos, leadingLength);

                lyricLine += gap;
                chordLine += QString(gap.length(), ' '); // Match spaces exactly

                // 2. Add the Chord to the top line (no brackets)
                QString chordName = match.captured(1);
                chordLine += "<span class='chord'>" + chordName + "</span>";

                // 3. Update position (skip the [chord] block in the original)
                currentPos = match.capturedEnd();
            }

            // 4. Add the remaining lyrics after the last chord
            lyricLine += line.mid(currentPos);

            // 5. Stack them with a single break in between
            result += chordLine + "<br>" + lyricLine + "<br>";
        }
    }
}

/*    for (QString line : lines) {
        line.remove('\r'); // Handle Windows line endings

        // Skip metadata we already have in the header
        if (line.startsWith("{t", Qt::CaseInsensitive) || line.startsWith("{k", Qt::CaseInsensitive)) continue;

        // Process rhythm symbols FIRST to avoid tag collision
        line.replace("/", "<span class='chord'>⚡</span>");
        line.replace("|", "<span style='color:" + colorLyrics + ";'>┃</span>");

        // Format Section Markers {c: Intro}
        if (line.contains("{c:", Qt::CaseInsensitive)) {
            line = "<b>" + line + "</b>";
        }

        // Apply Chord Colors [G]
        line.replace(QRegularExpression("\\[(.*?)\\]"), "<span class='chord'>[\\1]</span>");

        result += line + "<br>";
    }

    result += "</body></html>";
    return result;
}
*/

/* QString MainWindow::runInitialParse(const QString &rawInput) {
    // 1. Define display theme variables
    QString colorChord = "darkblue";
    QString colorLyrics = "#1A1A1A"; // 90% Black / Dark Charcoal

    // 2. Setup the Header with Global Monospace Styling
    // 'white-space: pre' is the key to keeping [G] aligned over lyrics
//    QString result = "<style> body { font-family: 'Consolas', 'Courier New', monospace; white-space: pre; background-color: white; color: " + colorLyrics + "; } </style>";

    // Update the beginning of your result string:
    QString result = "<html><head><style>";
    result += "body { font-family: 'Consolas', 'Courier New', monospace; ";
    result += "white-space: pre-wrap; background-color: white; color: " + colorLyrics + "; }";
    result += "span.chord { color: " + colorChord + "; font-weight: bold; }";
    result += "</style></head><body>";

    // Metadata Header Block
    QRegularExpression titleRegex("\\{(?:title|t):\\s*(.*)\\}", QRegularExpression::CaseInsensitiveOption);
    QRegularExpression keyRegex("\\{(?:key|k):\\s*(.*)\\}", QRegularExpression::CaseInsensitiveOption);
    auto titleMatch = titleRegex.match(rawInput);
    auto keyMatch = keyRegex.match(rawInput);



    result += "<div style='background-color: #f0f0f0; padding: 10px; border-bottom: 2px solid #1A1A1A;'>";
    result += "<b>--- ChordLab Analysis ---</b><br>";
    result += "TITLE: " + (titleMatch.hasMatch() ? titleMatch.captured(1) : "Unknown") + " | ";
    result += "KEY: " + (keyMatch.hasMatch() ? keyMatch.captured(1) : "Not Defined");
    result += "</div><br>";

    // 3. The Body Pass
    QStringList lines = rawInput.split('\n');
    for (QString line : lines) {
        // IMPORTANT: Do NOT use trimmed(). It kills alignment spaces.
        line.remove('\r');

        if (line.isEmpty()) {
            result += "<br>";
            continue;
        }

        if (line.startsWith("{t", Qt::CaseInsensitive) || line.startsWith("{k", Qt::CaseInsensitive)) continue;

        // Handle Special Grids
        if (line.contains("{sog}", Qt::CaseInsensitive)) {
            result += "<div style='background-color: #e6f3ff; font-style: italic;'><b>[Start of Rhythm Grid]</b><br>";
            continue;
        }
        if (line.contains("{eog}", Qt::CaseInsensitive)) {
            result += "<b>[End of Rhythm Grid]</b></div>";
            continue;
        }

        // Apply Formatting
        if (line.contains("{c:", Qt::CaseInsensitive) || line.contains("{comment:", Qt::CaseInsensitive)) {
            line = "<b>" + line + "</b>";
        }

        // Use the 'chord' class for color and bolding
        line.replace(QRegularExpression("\\[(.*?)\\]"), "<span class='chord'>[\\1]</span>");
        line.replace("/", "<span class='chord'>⚡</span>");
        line.replace("|", "<span style='color:" + colorLyrics + ";'>┃</span>");

        result += line + "<br>";
    }

    result += "</body></html>"; // Properly close the document
    return result;
} */

